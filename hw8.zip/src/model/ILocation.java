package model;

public interface ILocation {

  boolean online();

  String place();

}
