//package view;
//
//import controller.ControllerAdapter;
//import provider.controller.Features;
//import provider.model.User;
//
//import java.util.List;
//
//public class EventFrameAdapter implements provider.view.EventFrame {
//  private final EvtFrame evtFrame;
//
//  public EventFrameAdapter(EvtFrame evtFrame) {
//    this.evtFrame = evtFrame;
//  }
//  @Override
//  public void addFeatures(Features features) {
//    evtFrame.addListener();
//  }
//
//  @Override
//  public void displayAvailableUsers(List<User> users) {
//    evtFrame.
//  }
//}
