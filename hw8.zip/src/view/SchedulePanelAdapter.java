//package view;
//
//import provider.controller.Features;
//import provider.model.ReadOnlySchedule;
//
//public class SchedulePanelAdapter implements provider.view.SchedulePanel {
//
//  private final SchedulePanel schPanel;
//
//  public SchedulePanelAdapter(SchedulePanel schPanel) {
//    this.schPanel = schPanel;
//  }
//
//  @Override
//  public void displaySchedule(ReadOnlySchedule schedule) {
//
//  }
//
//  @Override
//  public void addFeatures(Features features) {
//
//  }
//}
