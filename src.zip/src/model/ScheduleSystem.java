package model;

public interface ScheduleSystem {

}
