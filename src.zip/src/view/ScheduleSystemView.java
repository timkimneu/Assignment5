package view;

public interface ScheduleSystemView {

}
