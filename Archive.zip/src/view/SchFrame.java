package view;

/**
 * Represents the interface for the schedule of a single user, but allowing
 * for the selection of different users to view the appropriate schedule
 * pertaining to that user.
 */
public interface SchFrame {
  // ignore
}
