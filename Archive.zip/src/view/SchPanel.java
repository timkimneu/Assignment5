package view;

import controller.ScheduleSystem;

/**
 * Creates an interface in order to visualize the users'
 * schedules. Includes a method that takes in the user
 * that is chosen, and will draw red blocks according
 * to the events in their schedules.
 */
public interface SchPanel {
  /**
   * Creates a method to draw dates
   *
   * @param user String of name of user
   */
  void drawDates(String user);

  /**
   * Creates a method to add a listener
   *
   * @param controller Controller that listens to model
   */
  void addListener(ScheduleSystem controller);
}
